# FirstNeuron
it's a simple and easy first practical test of doing a neural network with only a neuron in google colab 
